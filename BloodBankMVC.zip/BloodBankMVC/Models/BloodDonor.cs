using System;
using System.ComponentModel.DataAnnotations;

namespace BloodBankMVC.Models
{
    public class BloodDonor
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Name is required")]
        public string? Name { get; set; }

        [Required(ErrorMessage = "Phone is required")]
        [Phone(ErrorMessage = "Invalid phone number")]
        public string? Phone { get; set; }

        [Required(ErrorMessage = "City is required")]
        public string? City { get; set; }

        [Required(ErrorMessage = "Blood Group is required")]
        public string? BloodGroup { get; set; }

        [Required(ErrorMessage = "Donation Date is required")]
        [DataType(DataType.Date)]
        public DateTime DonationDate { get; set; }
    }
}
