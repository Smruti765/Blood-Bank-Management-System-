﻿using System.ComponentModel.DataAnnotations;

namespace BloodBankMVC.Models
{
    public class BloodStock
    {
        public int Id { get; set; }
        public string? BloodGroup { get; set; }
        public int UnitsAvailable { get; set; }       // यह property जरूर होनी चाहिए
        public DateTime ExpiryDate { get; set; }      // यह भी
                                                      // और भी properties
    }
}
