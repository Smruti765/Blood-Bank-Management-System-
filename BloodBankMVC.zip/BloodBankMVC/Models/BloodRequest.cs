﻿using System;
using System.ComponentModel.DataAnnotations;

namespace BloodBankMVC.Models
{
    public class BloodRequest
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Requestor Name is required")]
        public string? RequestorName { get; set; }

        [Required(ErrorMessage = "Blood Group is required")]
        public string? BloodGroup { get; set; }

        [Required(ErrorMessage = "Units is required")]
        [Range(1, 100, ErrorMessage = "Units must be between 1 and 100")]
        public int Units { get; set; }

        [Required(ErrorMessage = "Request Date is required")]
        [DataType(DataType.Date)]
        public DateTime RequestDate { get; set; }

        [Required(ErrorMessage = "Contact is required")]
        [Phone(ErrorMessage = "Invalid phone number")]
        public string? Contact { get; set; }
    }
}
