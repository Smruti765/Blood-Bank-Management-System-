using BloodBankMVC.Models;
using Microsoft.EntityFrameworkCore;

namespace BloodBankMVC.Data
{
    public class BloodBankContext : DbContext
    {
        public BloodBankContext(DbContextOptions<BloodBankContext> options)
            : base(options)
        {
        }

        public DbSet<BloodDonor> Donors { get; set; }
        public DbSet<BloodRequest> BloodRequests { get; set; }
        public DbSet<BloodStock> BloodStocks { get; set; }
    }
}
