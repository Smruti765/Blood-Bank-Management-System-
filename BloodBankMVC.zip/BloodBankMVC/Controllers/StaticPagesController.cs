﻿using Microsoft.AspNetCore.Mvc;

namespace BloodBankMVC.Controllers
{
    public class StaticPagesController : Controller
    {
        public IActionResult Contact()
        {
            return View();
        }

        public IActionResult About()
        {
            return View();
        }

        public IActionResult Logout()
        {
            // आप यहाँ session clear या auth logout कर सकते हैं
            // For now, just redirect to login or home
            return RedirectToAction("Index", "Home");
        }
    }
}
