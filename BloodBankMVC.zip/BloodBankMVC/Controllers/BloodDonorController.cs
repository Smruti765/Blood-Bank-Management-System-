﻿using BloodBankMVC.Data;
using BloodBankMVC.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

namespace BloodBankMVC.Controllers
{
    public class BloodDonorController : Controller
    {
        private readonly BloodBankContext _context;

        public BloodDonorController(BloodBankContext context)
        {
            _context = context;
        }

        // GET: /BloodDonor
        public async Task<IActionResult> Index()
        {
            var donors = await _context.Donors.ToListAsync();
            return View(donors);
        }

        // GET: /BloodDonor/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: /BloodDonor/Create
        [HttpPost]
        public async Task<IActionResult> Create(BloodDonor donor)
        {
            if (ModelState.IsValid)
            {
                _context.Donors.Add(donor);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(donor);
        }

        // GET: /BloodDonor/Edit/5
        public async Task<IActionResult> Edit(int id)
        {
            var donor = await _context.Donors.FindAsync(id);
            if (donor == null)
                return NotFound();

            return View(donor);
        }

        // POST: /BloodDonor/Edit/5
        [HttpPost]
        public async Task<IActionResult> Edit(BloodDonor donor)
        {
            if (ModelState.IsValid)
            {
                _context.Donors.Update(donor);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(donor);
        }

        // GET: /BloodDonor/Delete/5
        public async Task<IActionResult> Delete(int id)
        {
            var donor = await _context.Donors.FindAsync(id);
            if (donor == null)
                return NotFound();

            return View(donor);
        }

        // POST: /BloodDonor/Delete/5
        [HttpPost, ActionName("Delete")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var donor = await _context.Donors.FindAsync(id);
            if (donor != null)
            {
                _context.Donors.Remove(donor);
                await _context.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Index));
        }

        // GET: /BloodDonor/Details/5
        public async Task<IActionResult> Details(int id)
        {
            var donor = await _context.Donors.FindAsync(id);
            if (donor == null)
                return NotFound();

            return View(donor);
        }
        // GET: /BloodDonor/Search
        public IActionResult Search()
        {
            return View();
        }

        // POST: /BloodDonor/Search
        [HttpPost]
        public async Task<IActionResult> Search(string keyword)
        {
            var results = await _context.Donors
                .Where(d => d.Name.Contains(keyword) || d.City.Contains(keyword) || d.BloodGroup.Contains(keyword))
                .ToListAsync();

            return View("Search", results);
        }

    }
}
