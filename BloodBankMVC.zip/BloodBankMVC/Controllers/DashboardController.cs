﻿using Microsoft.AspNetCore.Mvc;

namespace BloodBankMVC.Controllers
{
    public class DashboardController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
