﻿using Microsoft.AspNetCore.Mvc;

namespace BloodBankMVC.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult About() => View();
        public IActionResult Contact() => View();
    }
}
